// ui_extensions/app.js
const sampleGames = [
  {id:'g1', title:'Breath Flow', tags:['relax','breath'], desc:'Guided breathing to calm your mind', stressDecrease:8},
  {id:'g2', title:'Color Calm', tags:['focus','relax'], desc:'Color-matching puzzle, slow paced', stressDecrease:6},
  {id:'g3', title:'Micro-Mind', tags:['focus'], desc:'Quick micro tasks to regain focus', stressDecrease:5}
];
const sampleSongs = [
  {id:'s1', title:'Ocean Hush', tags:['relax'], desc:'Ambient ocean sounds, 10 mins'},
  {id:'s2', title:'Study Bloom', tags:['focus'], desc:'Instrumental piano, steady tempo'},
  {id:'s3', title:'Wind Chimes', tags:['calm'], desc:'Soft chimes for background calm'}
];
const sampleMagazine = [
  {id:'m1', title:'Study Routines that Work', excerpt:'Tiny habits to boost retention and reduce burnout.'},
  {id:'m2', title:'Exam-week Calm', excerpt:'A 5-step pre-exam checklist to lower anxiety.'},
  {id:'m3', title:'Timeboxing for Students', excerpt:'Plan small focused sessions and short breaks.'}
];
// populate UI
document.addEventListener('DOMContentLoaded', ()=>{
  const gamesArea = document.getElementById('cards-area');
  const leaderboardList = document.getElementById('leader-list');
  const magazineArea = document.getElementById('mag-area');
  const modeButtons = document.querySelectorAll('.toggle-btn');
  const modePill = document.getElementById('mode-pill');
  const themeToggle = document.getElementById('theme-toggle');

  function renderList(kind){
    gamesArea.innerHTML='';
    const items = kind==='games'? sampleGames : sampleSongs;
    items.forEach(it=>{
      const div = document.createElement('div');
      div.className='card suggestion-card';
      div.innerHTML = `<strong>${it.title}</strong><div class="small">${it.desc}</div>`;
      div.onclick = ()=> openMoodModal(kind, it.id);
      gamesArea.appendChild(div);
    });
  }
  function renderLeader(){
    // sample data or localStorage
    let leaders = JSON.parse(localStorage.getItem('leaders')||'[]');
    if(leaders.length===0){
      leaders = [{name:'Asha',score:420},{name:'Ravi',score:360},{name:'Lina',score:310}];
    }
    leaderboardList.innerHTML='';
    leaders.slice(0,10).forEach(l=>{
      const li = document.createElement('li');
      li.innerHTML = `<span>${l.name}</span><strong>${l.score}</strong>`;
      leaderboardList.appendChild(li);
    });
  }
  function renderMagazine(){
    magazineArea.innerHTML='';
    sampleMagazine.forEach(m=>{
      const d = document.createElement('div');
      d.className='card small';
      d.style.marginBottom='8px';
      d.innerHTML = `<strong>${m.title}</strong><div class="small">${m.excerpt}</div>`;
      magazineArea.appendChild(d);
    });
  }
  // initial
  renderList('games'); renderLeader(); renderMagazine();
  // mode switches
  modeButtons.forEach(b=> b.addEventListener('click', ()=>{
    modeButtons.forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    const mode = b.dataset.mode;
    modePill.textContent = mode.toUpperCase();
    renderList(mode);
  }));
  // theme
  themeToggle.addEventListener('click', ()=>{
    const cur = document.body.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    document.body.setAttribute('data-theme', cur);
  });
  // modal actions
  window.openMoodModal = function(kind, id){
    const modal = document.getElementById('modal-back');
    modal.style.display='flex';
    modal.dataset.kind = kind;
    modal.dataset.id = id;
  }
  document.getElementById('m-cancel').onclick = ()=>{
    document.getElementById('modal-back').style.display='none';
  }
  document.querySelectorAll('.mood-btn').forEach(b=> b.onclick = (e)=>{
    const mood = e.target.dataset.mood;
    const {kind,id} = document.getElementById('modal-back').dataset;
    suggestForMood(kind,id,mood);
    document.getElementById('modal-back').style.display='none';
  });
  // sample suggestion algorithm
  function suggestForMood(kind,id,mood){
    const items = kind==='games'? sampleGames : sampleSongs;
    const picked = items.find(x=>x.id===id) || items[0];
    // simple mapping
    let suggestion;
    if(mood==='stressed'){
      suggestion = items.find(x=>x.tags && x.tags.includes('relax')) || picked;
    } else if(mood==='tired'){
      suggestion = items.find(x=>x.tags && x.tags.includes('calm')) || picked;
    } else if(mood==='focused'){
      suggestion = items.find(x=>x.tags && x.tags.includes('focus')) || picked;
    } else {
      suggestion = picked;
    }
    showSuggestionToast(suggestion, mood);
    // pretend to launch game/song (open a small player or new tab placeholder)
    // Also update leaderboard if it's a game and mood was improved
    if(kind==='games'){
      // increase score in localStorage
      let leaders = JSON.parse(localStorage.getItem('leaders')||'[]');
      leaders = leaders || [];
      // mock reward
      leaders.unshift({name:'You', score: Math.floor(Math.random()*300)+100});
      localStorage.setItem('leaders', JSON.stringify(leaders.slice(0,50)));
      renderLeader();
    }
  }
  function showSuggestionToast(item, mood){
    const t = document.getElementById('toast');
    t.innerHTML = `<strong>Suggested: ${item.title}</strong><div class="small">Because you said you feel ${mood}. ${item.desc || ''}</div>`;
    t.style.display='block';
    setTimeout(()=> t.style.display='none', 6000);
  }
});