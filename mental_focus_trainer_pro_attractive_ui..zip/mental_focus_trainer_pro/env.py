"""Focus environment with simple EEG-like simulated signal and curriculum scheduling."""
import random, math, numpy as np

class FocusEnv:
    def __init__(self, max_steps=40, curriculum_level=0, seed=None):
        self.max_steps = max_steps
        self.step_count = 0
        self.curriculum = curriculum_level  # influences base difficulty
        self.difficulty = 0
        self.last_rt = 0.5
        self.last_success = 1.0
        self.eeg = 0.5  # simulated EEG attention metric (0-1)
        self.done = False
        self.rng = random.Random(seed)

    def reset(self):
        self.step_count = 0
        self.difficulty = max(0, min(2, self.curriculum))
        self.last_rt = 0.5
        self.last_success = 1.0
        self.eeg = 0.5
        self.done = False
        return self._get_obs()

    def _get_obs(self):
        # obs: [rt_norm, success, difficulty/2, eeg]
        rt_norm = min(max(self.last_rt / 2.0, 0.0), 1.0)
        return np.array([rt_norm, float(self.last_success), float(self.difficulty)/2.0, float(self.eeg)], dtype=float)

    def step(self, action, user_rt=None, user_success=None):
        if self.done:
            raise RuntimeError('reset before step')
        self.step_count += 1
        self.difficulty = int(action)

        # simulate user if none provided
        if user_rt is None or user_success is None:
            base_rt = self.rng.gauss(0.33, 0.08)
            rt = base_rt * (1.0 + 0.28*self.difficulty) + self.rng.gauss(0, 0.05)
            success_prob = max(0.97 - 0.18*self.difficulty - 0.2*self.eeg, 0.12)
            success = self.rng.random() < success_prob
        else:
            rt = float(user_rt)
            success = bool(user_success)

        # EEG sim: success and low RT increase attention; difficulty increases cognitive load
        self.eeg = max(0.0, min(1.0, self.eeg + (0.05 if success and rt < 0.6 else -0.03) - 0.04*self.difficulty))

        self.last_rt = float(rt)
        self.last_success = 1.0 if success else 0.0

        # reward: prefer quick correct responses and stable EEG attention
        if success:
            reward = 1.0 - (rt * 0.8) - 0.06*self.difficulty + 0.5*(self.eeg - 0.5)
        else:
            reward = -0.8 - 0.08*self.difficulty - 0.4*(0.5 - self.eeg)

        if self.difficulty == 0:
            reward -= 0.02

        obs = self._get_obs()
        self.done = (self.step_count >= self.max_steps)
        info = {'rt': self.last_rt, 'success': self.last_success, 'eeg': self.eeg}
        return obs, reward, self.done, info
