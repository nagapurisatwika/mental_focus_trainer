# Mental Focus Trainer — Pro Edition

Features added in Pro edition:
- Flask backend with user profiles and leaderboard (JSON storage)
- Modern web frontend (HTML + JS) using Chart.js for live charts and reaction-test UI
- Environment with simulated EEG-like signal and curriculum progression
- PPO agent and training script
- Sample data and simple instructions

How to run:
1. Install dependencies: `pip install -r requirements.txt`
2. Start backend: `python3 web_app_full.py`
3. Open frontend: http://127.0.0.1:5000 (includes reaction test; results stored to leaderboard)

This package is a starter — extend with real EEG device, persistent DB, or multi-user auth as needed.
