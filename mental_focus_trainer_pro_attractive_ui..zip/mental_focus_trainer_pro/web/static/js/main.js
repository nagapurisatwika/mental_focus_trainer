// Simple frontend reaction test + chart and submit to backend
let canvas = document.getElementById('chart');
let ctx = canvas.getContext('2d');
let chart = new Chart(ctx, {type:'line', data:{labels:[], datasets:[{label:'RT (s)', data:[]}]}, options:{}});

let startBtn = document.getElementById('start');
let viewBtn = document.getElementById('view');
let taskDiv = document.getElementById('task');
let leaderDiv = document.getElementById('leader');
let nameIn = document.getElementById('name');

startBtn.onclick = async function(){
  leaderDiv.innerHTML=''; taskDiv.innerHTML='Get ready...';
  await delay(800);
  let trials = 12; let rts=[]; let rewards=[]; let eegs=[];
  for(let i=0;i<trials;i++){
    taskDiv.innerHTML='Wait for it...'; await delay(500 + Math.random()*800);
    taskDiv.innerHTML='<div style="width:60px;height:60px;background:blue;margin:10px auto;" id="stim"></div>';
    let t0 = performance.now();
    let pressed=false;
    function listener(e){ if(e.code==='Space'){ if(!pressed){ pressed=true; let rt=(performance.now()-t0)/1000; rts.push(rt); document.removeEventListener('keydown',listener); }}}
    document.addEventListener('keydown', listener);
    // timeout 2s
    let waited=0;
    while(!pressed && waited<2000){ await delay(50); waited+=50;}
    if(!pressed){ rts.push(2.2); document.removeEventListener('keydown',listener); }
    // simulate reward/eeg locally for visual feedback
    let rt = rts[rts.length-1];
    let reward = Math.max(0, 1.0 - rt); rewards.push(reward);
    let eeg = 0.5 + (Math.random()-0.5)*0.2 + (reward-0.5)*0.2; eegs.push(Math.max(0,Math.min(1,eeg)));
    updateChart(rts);
    taskDiv.innerHTML='Last RT: '+rt.toFixed(3)+'s';
    await delay(400);
  }
  // send to backend
  let avg_rt = rts.reduce((a,b)=>a+b,0)/rts.length;
  let avg_reward = rewards.reduce((a,b)=>a+b,0)/rewards.length;
  let eeg_avg = eegs.reduce((a,b)=>a+b,0)/eegs.length;
  fetch('/api/submit', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name:nameIn.value, steps:rts.length, avg_rt:avg_rt, avg_reward:avg_reward, eeg_avg:eeg_avg})});
  alert('Session complete — avg_rt='+avg_rt.toFixed(3)+' avg_reward='+avg_reward.toFixed(3));
}

viewBtn.onclick = async function(){
  let res = await fetch('/api/leaderboard'); let data = await res.json();
  leaderDiv.innerHTML='<h3>Leaderboard</h3><ol>' + data.map(d=>`<li>${d.name} — reward:${Number(d.avg_reward).toFixed(3)} rt:${Number(d.avg_rt).toFixed(3)}</li>`).join('') + '</ol>';
}

function updateChart(rts){
  chart.data.labels = rts.map((_,i)=>i+1);
  chart.data.datasets[0].data = rts;
  chart.update();
}

function delay(ms){ return new Promise(r=>setTimeout(r,ms)); }
