"""Flask backend serving the Pro frontend and simple API endpoints for saving results and leaderboard."""
from flask import Flask, render_template, request, jsonify, send_from_directory
import os, json, time
from env import FocusEnv
from ppo_agent import PPOAgent

app = Flask(__name__, static_folder='web/static', template_folder='web/templates')
DATA_FILE = 'data/leaderboard.json'
MODEL_PATH = 'models/ppo_final.pth'

def ensure_data():
    if not os.path.exists('data'):
        os.makedirs('data')
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE,'w') as f:
            json.dump([], f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:p>')
def static_files(p):
    return send_from_directory('web/static', p)

@app.route('/api/submit', methods=['POST'])
def submit():
    ensure_data()
    payload = request.json
    # expected: {name, steps, avg_rt, avg_reward, eeg_avg}
    entry = {'name': payload.get('name','anon'), 'timestamp': time.time(), 'steps': payload.get('steps',0),
             'avg_rt': payload.get('avg_rt',0.0), 'avg_reward': payload.get('avg_reward',0.0), 'eeg': payload.get('eeg_avg',0.0)}
    with open(DATA_FILE,'r+') as f:
        data = json.load(f)
        data.append(entry)
        f.seek(0); f.truncate(); json.dump(data, f, indent=2)
    return jsonify({'status':'ok'})

@app.route('/api/leaderboard')
def leaderboard():
    ensure_data()
    with open(DATA_FILE,'r') as f:
        data = json.load(f)
    # sort by avg_reward desc
    data_sorted = sorted(data, key=lambda x: x.get('avg_reward',0), reverse=True)
    return jsonify(data_sorted[:20])

@app.route('/api/model_action', methods=['POST'])
def model_action():
    # optional: server can provide action suggestion from trained model
    payload = request.json
    obs = payload.get('obs')
    agent = PPOAgent()
    if os.path.exists(MODEL_PATH):
        try:
            agent.load(MODEL_PATH)
        except Exception:
            pass
    if obs is None:
        return jsonify({'action':0})
    a, logp, val = agent.get_action(obs)
    return jsonify({'action': a})

if __name__=='__main__':
    app.run(debug=True)
