import torch, torch.nn as nn, torch.optim as optim, numpy as np

class ActorCritic(nn.Module):
    def __init__(self, obs_dim, n_actions):
        super().__init__()
        self.fc = nn.Sequential(nn.Linear(obs_dim,64), nn.ReLU())
        self.actor = nn.Sequential(nn.Linear(64,64), nn.ReLU(), nn.Linear(64,n_actions))
        self.critic = nn.Sequential(nn.Linear(64,64), nn.ReLU(), nn.Linear(64,1))
    def forward(self,x):
        h = self.fc(x.float())
        return self.actor(h), self.critic(h)

class PPOAgent:
    def __init__(self, obs_dim=4, n_actions=3, lr=3e-4, clip=0.2):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.net = ActorCritic(obs_dim,n_actions).to(self.device)
        self.opt = optim.Adam(self.net.parameters(), lr=lr)
        self.clip = clip

    def get_action(self, obs):
        import torch, numpy as np
        obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
        logits, val = self.net(obs_t)
        probs = torch.softmax(logits, dim=-1)
        dist = torch.distributions.Categorical(probs)
        a = dist.sample()
        return int(a.item()), float(dist.log_prob(a).item()), float(val.item())

    def evaluate(self, obs_b, act_b):
        import torch
        logits, vals = self.net(torch.tensor(obs_b, dtype=torch.float32).to(self.device))
        probs = torch.softmax(logits, dim=-1)
        dist = torch.distributions.Categorical(probs)
        return dist.log_prob(torch.tensor(act_b).to(self.device)), vals.squeeze(-1), dist.entropy().mean()

    def update(self, traj, epochs=4, gamma=0.99, lam=0.95):
        import numpy as np, torch
        obs = traj['obs']; acts = traj['acts']; rews = traj['rews']; old_logp = traj['logp']; vals = traj['vals']
        # compute advantages (simple)
        returns = []
        G = 0
        for r in reversed(rews):
            G = r + gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32).to(self.device)
        adv = returns - torch.tensor(vals, dtype=torch.float32).to(self.device)
        adv = (adv - adv.mean())/(adv.std()+1e-8)
        old_logp_t = torch.tensor(old_logp, dtype=torch.float32).to(self.device)
        for _ in range(epochs):
            logp, vals_pred, ent = self.evaluate(obs, acts)
            ratio = torch.exp(logp - old_logp_t)
            surr1 = ratio * adv
            surr2 = torch.clamp(ratio, 1-self.clip, 1+self.clip) * adv
            actor_loss = -torch.min(surr1, surr2).mean()
            critic_loss = nn.MSELoss()(vals_pred, returns)
            loss = actor_loss + 0.5*critic_loss - 0.01*ent
            self.opt.zero_grad(); loss.backward(); self.opt.step()
        return float(loss.item())

    def save(self, path):
        import torch
        torch.save(self.net.state_dict(), path)
    def load(self, path):
        import torch
        self.net.load_state_dict(torch.load(path, map_location=self.device))
