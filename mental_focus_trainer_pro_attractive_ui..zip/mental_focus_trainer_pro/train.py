"""Train the PPO agent with curriculum progression and save model + logs."""
import os, numpy as np, pandas as pd
from env import FocusEnv
from ppo_agent import PPOAgent

def simulated_user(difficulty, eeg):
    import random
    base_rt = random.gauss(0.33,0.08)
    rt = base_rt * (1.0 + 0.28*difficulty) + random.gauss(0,0.05)
    success_prob = max(0.95 - 0.18*difficulty - 0.2*(0.5-eeg), 0.12)
    succ = random.random() < success_prob
    return rt, succ

def run_episode(env, agent):
    s = env.reset()
    traj = {'obs':[], 'acts':[], 'rews':[], 'logp':[], 'vals':[]}
    total = 0.0
    for t in range(env.max_steps):
        a, logp, val = agent.get_action(s)
        rt, succ = simulated_user(a, env.eeg)
        ns, r, done, info = env.step(a, user_rt=rt, user_success=succ)
        traj['obs'].append(s); traj['acts'].append(a); traj['rews'].append(r); traj['logp'].append(logp); traj['vals'].append(val)
        s = ns; total += r
        if done: break
    # convert to arrays
    for k in ['obs','acts','rews','logp','vals']:
        traj[k] = np.array(traj[k])
    return traj, total

def train(epochs=200):
    os.makedirs('models', exist_ok=True); os.makedirs('data', exist_ok=True)
    agent = PPOAgent(); rows=[]
    curriculum = 0
    for ep in range(1, epochs+1):
        env = FocusEnv(max_steps=40, curriculum_level=curriculum)
        traj, total = run_episode(env, agent)
        loss = agent.update({'obs':traj['obs'],'acts':traj['acts'],'rews':traj['rews'],'logp':traj['logp'],'vals':traj['vals']})
        rows.append({'ep':ep,'reward':float(total),'loss':loss,'curriculum':curriculum})
        if ep%20==0:
            # increase curriculum if agent performs well recently
            recent = [r['reward'] for r in rows[-20:]]
            if sum(recent)/len(recent) > 5.0 and curriculum < 2:
                curriculum += 1
        if ep%50==0:
            agent.save(f'models/ppo_ep{ep}.pth')
    import pandas as pd
    pd.DataFrame(rows).to_csv('data/train_log.csv', index=False)
    agent.save('models/ppo_final.pth')
    print('Training finished. Logs in data/, models/ppo_final.pth saved.')

if __name__=='__main__':
    train(epochs=200)
